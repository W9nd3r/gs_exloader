#pragma once

#include "..\..\includes.hpp"

class bunnyhop : public singleton <bunnyhop>
{
public:
	void create_move();
};