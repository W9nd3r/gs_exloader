#pragma once

#include "..\..\includes.hpp"

class spammers : public  singleton< spammers > {
public:
	void clan_tag();
	void gamesense_tag();
};