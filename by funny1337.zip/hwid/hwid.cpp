#include "hwid.h"
#include "base64.h"
#include "SMBIOS.h"
#include <powerbase.h>
#include "../configs/configs.h"
#include "conv.h"

#include <codecvt>
#include <string>
