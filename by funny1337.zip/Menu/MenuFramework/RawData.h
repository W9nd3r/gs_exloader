#include "../Globalincludes.h"

namespace RawData
{
	extern BYTE TabIcons[];
	extern BYTE TabIcons2[];
	extern BYTE TabIcons3[];
	extern BYTE TabIcons4[];
	extern BYTE BgTexture[];
	extern BYTE LBIcons[];
}